#Version 0.1 (beta)
#This file last revised:
#2020-01-31


#DO NOT MODIFY THIS SCRIPT.

#THIS SCRIPT IS CALLED AT THE BEGINNING OF THE SOURCE FILE YOU WILL WORK WITH ON THIS EXERCISE.
#This script executes the following tasks:
#1) Installs TWO R packages required for this exercise.
#2) Creates a new directory called "Data".
#3) Downloads the data file used for this exercise (anscombe.csv), and saves it in the new "Data" directory. 


#INSTALL PACKAGES
#These commands install two packages that will be needed for this exercise.
if(!require(readr)) install.packages("readr", repos = "https://cloud.r-project.org/")
if(!require(DescTools)) install.packages("DescTools", repos = "https://cloud.r-project.org/")


#CREATE A NEW DIRECTORY (IN THE TOP LEVEL OF THE R PROJECT) CALLED Data.
dir.create("Data")


#DOWNLOAD THE DATA For THIS EXERCISE from the GitHub repository where it is stored, and save it in the Data directory that was just created, giving the file the name anscombe.csv.
download.file("https://raw.githubusercontent.com/ProjectTIER/public/master/anscombe.csv","data/anscombe.csv", mode = "wb")


